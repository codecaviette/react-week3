import React, { Component } from 'react';
import './App.css';
import { BrowserRouter, Switch, Route, Redirect } from 'react-router-dom';
import StudentsPage from './Pages/StudentsPage';
import ContactPage from './Pages/ContactPage';
import UserShowPage from './Pages/UserShowPage';


class App extends Component {
  render() {
    return (
      <BrowserRouter>
        <Switch>
          <Route exact path="/" component={StudentsPage}/>
          <Route exact path="/contact" component={ContactPage}/>
          <Route exact path="/users/:id" component={UserShowPage}/>   {/* :id gives UserShowPage component access to this URL variable*/}
          <Route path="*">        {/* The asterisk means "everything else" ... redirects to... */}
            <Redirect to="/" />
          </Route>
        </Switch>
      </BrowserRouter>
    );
  }
}

export default App