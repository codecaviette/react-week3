import React, { Component } from 'react';
import { Link } from 'react-router-dom'; 
import UserShowPage from './UserShowPage';

const STUDENTS = [
    {
        id: 0,
        name: "Jenny"
    },
    {
        id: 1,
        name: "Emily"
    },
    {
        id: 2,
        name: "Aaron"
    }
]

class StudentsPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            students: STUDENTS
        }
    }

    render() {
        return (
            <div>
                <h1>Students Page</h1>
                <Link to="/contact"> Go to the Contact Page </Link>
                <UserShowPage students={this.state.students} />
            </div>
        )
    }
}

export default StudentsPage
