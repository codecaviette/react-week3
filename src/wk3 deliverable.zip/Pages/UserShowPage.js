import React, { Component } from 'react'

class UserShowPage extends Component {
    render() {
        return (
            <div>
               <h3> User Details </h3>                     
            </div>
        )
    }
}

export default UserShowPage
